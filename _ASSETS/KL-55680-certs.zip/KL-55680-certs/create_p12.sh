#!/bin/sh

# create p12
openssl pkcs12 -export -out sign.ergodirekt.de.p12 -inkey sign.ergodirekt.de.key -in sign.ergodirekt.de.crt

# verify:
openssl pkcs12 -in sign.ergodirekt.de.p12 -nokeys -clcerts
